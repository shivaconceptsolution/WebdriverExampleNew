package scs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginScript {

	static WebDriver driver;
	void openUrl()
	{
		System.setProperty("webdriver.chrome.driver","c://chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://eroomrent.in/ownerlogin.php");
	}
	void positiveTest()
	{
		WebElement txtemail = driver.findElement(By.name("txtEmail"));
		txtemail.sendKeys("nitinjatav@gmail.com");
		WebElement txtpass = driver.findElement(By.name("txtPassword"));
		txtpass.sendKeys("12345678");
		WebElement btn=driver.findElement(By.name("btnsubmit"));
		btn.click();
		String s = driver.getCurrentUrl();
		if(s.equals("https://eroomrent.in/owner/dashboard.php"))
		{
			System.out.println("Login Successfully");
			driver.findElement(By.linkText("Add Room")).click();
			Select loc = new Select(driver.findElement(By.name("ddllocation")));
			loc.selectByIndex(2);
			Select cat = new Select(driver.findElement(By.name("ddlcat")));
			cat.selectByIndex(2);
		//	Thread.sleep(3000);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
			Select scat = new Select(driver.findElement(By.name("ddlsubcat")));
			scat.selectByIndex(2);
			driver.findElement(By.name("txtdesc")).sendKeys("description");
			driver.findElement(By.name("file")).sendKeys("d://core.png");
			driver.findElement(By.name("txtamount")).sendKeys("1200");
			driver.findElement(By.name("txtfacility")).sendKeys("facility ");
			driver.findElement(By.name("btnsubmit")).click();
			//driver.findElement(By.linkText("Logout")).click();
			//driver.close();
			
		}
		else
		{
			System.out.println("Problem in login");
		}
	}
	void nigativeTestWithInvalidPassword()
	{
		
		WebElement txtemail = driver.findElement(By.name("txtEmail"));
		txtemail.sendKeys("nitinjatav@gmail.com");
		WebElement txtpass = driver.findElement(By.name("txtPassword"));
		txtpass.sendKeys("123456789");
		WebElement btn=driver.findElement(By.name("btnsubmit"));
		btn.click();
		String s = driver.getCurrentUrl();
		if(s.equals("https://eroomrent.in/owner/dashboard.php"))
		{
			System.out.println("Login Successfully");
		}
		else
		{
			System.out.println("Invalid Password");
		}
	}
	
	void nigativeTestWithInvalidUserID()
	{
		openUrl();
		WebElement txtemail = driver.findElement(By.name("txtEmail"));
		txtemail.sendKeys("nitinjatav12@gmail.com");
		WebElement txtpass = driver.findElement(By.name("txtPassword"));
		txtpass.sendKeys("12345678");
		WebElement btn=driver.findElement(By.name("btnsubmit"));
		btn.click();
		String s = driver.getCurrentUrl();
		if(s.equals("https://eroomrent.in/owner/dashboard.php"))
		{
			System.out.println("Login Successfully");
		}
		else
		{
			System.out.println("Invalid Userid");
		}
	}
	
	public static void main(String[] args) {
		
		LoginScript obj = new LoginScript();
		obj.openUrl();
		obj.positiveTest();
	//	obj.nigativeTestWithInvalidUserID();
	//	obj.nigativeTestWithInvalidPassword();

	}

}
