package scs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwithtoExample2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","c://chromedriver.exe");;
		WebDriver scs = new ChromeDriver();
		scs.get("http://output.jsbin.com/usidix/1");
		WebElement ele = scs.findElement(By.tagName("input"));
		ele.click();
		String s = scs.switchTo().alert().getText();
		System.out.println(s);
		scs.switchTo().alert().accept();
		

	}

}
